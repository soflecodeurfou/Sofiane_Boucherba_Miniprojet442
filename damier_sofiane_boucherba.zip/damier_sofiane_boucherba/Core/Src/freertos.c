/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "stm32746g_discovery_lcd.h"
#include "stm32746g_discovery_ts.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#define NB_LIGNES    10
#define NB_COLS      10
#define CELL_SIZE   26
#define NUM_CELLS_X 10
#define NUM_CELLS_Y 10
#define OFFSET_X     50     // marge gauche
#define OFFSET_Y     30     // marge haute
TS_StateTypeDef TS_State;



int tour = 0;
extern int damier[11][11];
int damierMisAJour = 1;

void drawDamier(void);

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
osThreadId defaultTaskHandle;
osThreadId affichageHandle;
osThreadId coupsHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const * argument);
void StartTask02(void const * argument);
void StartTask03(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* definition and creation of affichage */
  osThreadDef(affichage, StartTask02, osPriorityIdle, 0, 1024);
  affichageHandle = osThreadCreate(osThread(affichage), NULL);

  /* definition and creation of coups */
  osThreadDef(coups, StartTask03, osPriorityIdle, 0, 128);
  coupsHandle = osThreadCreate(osThread(coups), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_StartTask02 */
/**
* @brief Function implementing the affichage thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTask02 */
void StartTask02(void const * argument)
{
    char text[50];

    for (;;)
    {
    	int gain_bleu = 1;
    	int gain_jaune = 1;

        if (damierMisAJour == 1)
        {
            for (int ligne = 1; ligne <= NB_LIGNES; ligne++) {
                for (int col = 1; col <= NB_COLS; col++) {


                    int piece = damier[ligne][col];

                    uint16_t x = 90 + (col - 1) * CELL_SIZE;
                    uint16_t y = (ligne - 1) * CELL_SIZE;

                    // 1. Choisir couleur de fond (damier noir/blanc)
                    uint16_t fond = ((ligne + col) % 2 == 0) ? LCD_COLOR_WHITE : LCD_COLOR_BLACK;
                    BSP_LCD_SetTextColor(fond);
                    BSP_LCD_FillRect(x, y, CELL_SIZE, CELL_SIZE);

                    // 2. Dessiner la pièce si présente
                    switch (piece) {
                        case 1: // pion joueur bleu
                            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
                            gain_jaune =0;
                            BSP_LCD_FillCircle(x + CELL_SIZE / 2, y + CELL_SIZE / 2, 10);
                            break;
                        case 2: // pion joueur jaune
                            BSP_LCD_SetTextColor(LCD_COLOR_YELLOW);
                            gain_bleu =0;
                            BSP_LCD_FillCircle(x + CELL_SIZE / 2, y + CELL_SIZE / 2, 10);
                            break;
                        case 3: // dame joueur bleu
                            BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
                            gain_jaune =0;
                            BSP_LCD_FillRect(x + 4, y + 4, CELL_SIZE - 8, CELL_SIZE - 8);
                            break;
                        case 4: // dame joueur jaune
                            BSP_LCD_SetTextColor(LCD_COLOR_YELLOW);
                            gain_bleu =0;
                            BSP_LCD_FillRect(x + 4, y + 4, CELL_SIZE - 8, CELL_SIZE - 8);
                            break;
                        default:
                            break; // case vide
                    }
                }
            }

            damierMisAJour = 0;
            if (gain_bleu==1){
            	BSP_LCD_Clear(LCD_COLOR_YELLOW);
            	                        	BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
            	                        	 sprintf(text, "Gain des jaunes!");
            	                        	 BSP_LCD_DisplayStringAtLine(5, (uint8_t*)text);

            }
            if (gain_jaune==1){
             	BSP_LCD_Clear(LCD_COLOR_BLUE);
                        	BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
                        	 sprintf(text, "Gain des bleus!");
                        	 BSP_LCD_DisplayStringAtLine(5, (uint8_t*)text);
                        	                        }
            }
        }

        osDelay(50);
    }


void StartTask03(void const * argument)
{
    char text[50];
    int i_sec = -1, j_sec = -1;

    for (;;)
    {
        /* 1) Touch reading */
        BSP_TS_GetState(&TS_State);
        if (!TS_State.touchDetected) {
            osDelay(15);
            continue;
        }

        /* 2) X/Y → indices 1..10 conversion */
        uint16_t tx = TS_State.touchX[0];
        uint16_t ty = TS_State.touchY[0];
        if (tx < 90) {
            osDelay(15);
            continue;
        }
        int j = (tx - 90) / 26 + 1;    // column
        int i = ty            / 26 + 1; // row
        if (i < 1 || i > NB_LIGNES || j < 1 || j > NB_COLS || damier[i][j] == -1) {
            osDelay(15);
            continue;
        }

        /* 3) Global check: mandatory capture somewhere? */
        int dirG        = (tour == 0) ? +1 : -1;
        int advG        = (tour == 0) ? 1 : 2;
        int globalPrise = 0;
        for (int x = 1; x <= NB_LIGNES && !globalPrise; x++) {
            for (int y = 1; y <= NB_COLS && !globalPrise; y++) {
                if (damier[x][y] == (tour == 0 ? 2 : 1) || damier[x][y] == (tour == 0 ? 4 : 3)) {
                    // Check all directions (forward and backward)
                    for (int dir_mult = -1; dir_mult <= 1 && !globalPrise; dir_mult += 2) {
                        int current_dir = dirG * dir_mult;
                        // Check right
                        int m1 = x + current_dir, n1 = y + 1;
                        int m2 = x + 2*current_dir, n2 = y + 2;
                        if (m1>=1 && m1<=NB_LIGNES && n1>=1 && n1<=NB_COLS &&
                            m2>=1 && m2<=NB_LIGNES && n2>=1 && n2<=NB_COLS &&
                            damier[m1][n1] == advG && damier[m2][n2] == 0)
                        {
                            globalPrise = 1;
                            break;
                        }
                        // Check left
                        m1 = x + current_dir; n1 = y - 1;
                        m2 = x + 2*current_dir; n2 = y - 2;
                        if (m1>=1 && m1<=NB_LIGNES && n1>=1 && n1<=NB_COLS &&
                            m2>=1 && m2<=NB_LIGNES && n2>=1 && n2<=NB_COLS &&
                            damier[m1][n1] == advG && damier[m2][n2] == 0)
                        {
                            globalPrise = 1;
                            break;
                        }
                    }
                }
            }
        }

        /* 4) FIRST CLICK: select pawn or dame */
        if (i_sec < 0) {
            if ((tour == 0 && damier[i][j] != 2 && damier[i][j] != 4) ||
                (tour == 1 && damier[i][j] != 1 && damier[i][j] != 3))
            {
                osDelay(15);
                continue;
            }
            if (globalPrise) {
                int localPrise = 0;
                int dg = dirG;
                // Check all directions (forward and backward)
                for (int dir_mult = -1; dir_mult <= 1 && !localPrise; dir_mult += 2) {
                    int current_dir = dg * dir_mult;
                    // Check right
                    if (i + current_dir >=1 && i + current_dir <= NB_LIGNES && j +1 >=1 && j +1 <= NB_COLS &&
                        i + 2*current_dir >=1 && i + 2*current_dir <= NB_LIGNES && j +2 >=1 && j +2 <= NB_COLS &&
                        damier[i + current_dir][j +1] == advG && damier[i + 2*current_dir][j +2] == 0)
                    {
                        localPrise = 1;
                        break;
                    }
                    // Check left
                    if (i + current_dir >=1 && i + current_dir <= NB_LIGNES && j -1 >=1 && j -1 <= NB_COLS &&
                        i + 2*current_dir >=1 && i + 2*current_dir <= NB_LIGNES && j -2 >=1 && j -2 <= NB_COLS &&
                        damier[i + current_dir][j -1] == advG && damier[i + 2*current_dir][j -2] == 0)
                    {
                        localPrise = 1;
                        break;
                    }
                }
                if (!localPrise) {
                    BSP_LCD_SetTextColor(LCD_COLOR_RED);
                    sprintf(text, "Prise obligatoire!");
                    BSP_LCD_DisplayStringAtLine(5, (uint8_t*)text);
                    osDelay(200);
                    continue;
                }
            }
            i_sec = i;
            j_sec = j;
            osDelay(200);
            continue;
        }

        /* 5) SECOND CLICK: execute capture or move */
        int dir        = dirG;
        int adversaire = advG;
        int miseAJour  = 0;

        /* 5a) Check for possible capture */
        int prisePossible = 0;
        // Check all directions (forward and backward)
        for (int dir_mult = -1; dir_mult <= 1 && !prisePossible; dir_mult += 2) {
            int current_dir = dir * dir_mult;
            // Check right
            int m1 = i_sec + current_dir, n1 = j_sec + 1;
            int m2 = i_sec + 2*current_dir, n2 = j_sec + 2;
            if (m1>=1 && m1<=NB_LIGNES && n1>=1 && n1<=NB_COLS &&
                m2>=1 && m2<=NB_LIGNES && n2>=1 && n2<=NB_COLS &&
                damier[m1][n1] == adversaire && damier[m2][n2] == 0)
            {
                prisePossible = 1;
                break;
            }
            // Check left
            m1 = i_sec + current_dir; n1 = j_sec - 1;
            m2 = i_sec + 2*current_dir; n2 = j_sec - 2;
            if (m1>=1 && m1<=NB_LIGNES && n1>=1 && n1<=NB_COLS &&
                m2>=1 && m2<=NB_LIGNES && n2>=1 && n2<=NB_COLS &&
                damier[m1][n1] == adversaire && damier[m2][n2] == 0)
            {
                prisePossible = 1;
                break;
            }
        }

        /* 5a) Mandatory capture */
        if (globalPrise && prisePossible)
        {
            BSP_LCD_SetTextColor(LCD_COLOR_RED);
            sprintf(text, "Prise obligatoire!");
            BSP_LCD_DisplayStringAtLine(5, (uint8_t*)text);

            int dj = (j > j_sec) ? +1 : -1;
            int di = (i > i_sec) ? +1 : -1;
            int mi = i_sec + di, mj = j_sec + dj;
            int ni = i_sec + 2*di, nj = j_sec + 2*dj;

            if (i == ni && j == nj)
            {
                damier[ni][nj] = damier[i_sec][j_sec];
                damier[i_sec][j_sec] = 0;
                damier[mi][mj] = 0;
                damierMisAJour = 1;
                miseAJour = 1;
                i_sec = ni; j_sec = nj;

                // Promote to dame after capture
                if ((damier[ni][nj] == 2 && ni == NB_LIGNES) || (damier[ni][nj] == 1 && ni == 1)) {
                    damier[ni][nj] += 2;
                }

                int reprise = 0;
                // Check all directions for reprise
                for (int dir_mult = -1; dir_mult <= 1 && !reprise; dir_mult += 2) {
                    int current_dir = dir * dir_mult;
                    // Check right
                    int m1 = i_sec + current_dir, n1 = j_sec + 1;
                    int m2 = i_sec + 2*current_dir, n2 = j_sec + 2;
                    if (m1>=1 && m1<=NB_LIGNES && n1>=1 && n1<=NB_COLS &&
                        m2>=1 && m2<=NB_LIGNES && n2>=1 && n2<=NB_COLS &&
                        damier[m1][n1] == adversaire && damier[m2][n2] == 0)
                        reprise = 1;
                    // Check left
                    m1 = i_sec + current_dir;
                    n1 = j_sec - 1;
                    m2 = i_sec + 2*current_dir;
                    n2 = j_sec - 2;
                    if (m1>=1 && m1<=NB_LIGNES && n1>=1 && n1<=NB_COLS &&
                        m2>=1 && m2<=NB_LIGNES && n2>=1 && n2<=NB_COLS &&
                        damier[m1][n1] == adversaire && damier[m2][n2] == 0)
                        reprise = 1;
                }

                if (!reprise) {
                    tour   = 1 - tour;
                    i_sec  = -1;
                    j_sec  = -1;
                }
                osDelay(200);
                continue;
            }
            osDelay(200);
            continue;
        }

        /* 5b) Simple move */
        if (!globalPrise)
        {
            int v0 = damier[i_sec][j_sec];

            /* DAME (3/4): any diagonal one step */
            if ((v0 == 3 || v0 == 4) &&
                abs(i - i_sec) == 1 &&
                abs(j - j_sec) == 1 &&
                damier[i][j] == 0)
            {
                damier[i][j] = v0;
                damier[i_sec][j_sec] = 0;
                miseAJour = 1;
                damierMisAJour = 1;
                tour = 1 - tour;
            }
            /* PION (1/2): forward diagonal only */
            else if ((v0 == 1 || v0 == 2) &&
                     i == i_sec + dir &&
                     (j == j_sec - 1 || j == j_sec + 1) &&
                     damier[i][j] == 0)
            {
                damier[i][j] = v0;
                damier[i_sec][j_sec] = 0;
                /* Promotion */
                if (v0 == 2 && i == NB_LIGNES) damier[i][j] = 4;
                if (v0 == 1 && i == 1) damier[i][j] = 3;
                miseAJour = 1;
                damierMisAJour = 1;
                tour = 1 - tour;
            }
        }

        /* 6) End turn if a move was made */
        if (miseAJour) {
            i_sec = -1;
            j_sec = -1;
        }

        osDelay(200);
    }
}



/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */



